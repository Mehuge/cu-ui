interface Carousel {
    next();
    prev();
}
interface JQuery {
    carousel3d(args?: Object): Carousel;
}