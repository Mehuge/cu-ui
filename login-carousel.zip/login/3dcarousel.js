/*
* Flux 3D Carousel
* Author: Dean Coulter
* Licensed under the MIT license
* 
* Version 0.1
*/

(function($){
    $.fn.carousel3d = function (args) {

        args = args || { spread: 0.75, next: $('.next'), prev: $('.prev') };

        var el = ({
            carousel_frame: $(this)
        });

        var size = el.carousel_frame.children().size();	
        var panelSize = el.carousel_frame.width();
        var translateZ = Math.round( ( panelSize / args.spread ) / Math.tan( Math.PI / size ) );

        el.carousel_frame.css({
            "transform": "rotateY(0deg) translateZ(-"+translateZ+"px)"
        })

        var rotateY = 0;
        var rotate_int = 0;
        var ry =  360/size;
        var box = 0;

        function animate_slider(){
            rotateY = ry*rotate_int;

            for(i=0;i<size;i++){
                var z = (rotate_int*ry)+(i*ry);		
                el.carousel_frame.children("figure:eq("+i+")").css({
                    "transform":"rotateY("+z+"deg ) translateZ("+translateZ+"px)"
                });
            }

            rotateY = 0;
            box = 0; // reset rotateY, ready for re-use
        }

        animate_slider();

        args.next.on("click", function(){
            rotate_int -=1;
            animate_slider();
        });

        args.prev.on("click", function () {
            rotate_int +=1;
            animate_slider();
        });

        // capture scroll weel events
        var MouseWheel = function (e) {
            var render;
            e = e.originalEvent;
            if (e.detail) {
                e.wheelDelta = e.detail;
                e.wheelDeltaX = e.wheelDeltaY = 0;
                if (e.shiftKey) e.wheelDeltaX = e.detail; else e.wheelDeltaY = e.detail;
            }
            if (!e.shiftKey && e.wheelDeltaY != 0) {
                rotate_int += e.wheelDeltaY < 0 ? -1 : 1;
                animate_slider();
            }
            if (render) renderGraph(_cu_tracker);
            e.preventDefault();
        };

        $('#characters-container').on("mousewheel", MouseWheel);
        $('#characters-container').on("DOMMouseScroll", MouseWheel);

        el.carousel_frame.children().on("click", function () {
            var new_int = $(this).index();
            var cur_int = Math.abs(rotate_int) % size;
            if (cur_int >= size - 3 && new_int < 3) {
                cur_int -= size;
            } else {
                if (new_int >= size - 3 && cur_int < 3) {
                    new_int -= size;
                }
            }
            if (new_int < cur_int) {
                rotate_int += cur_int - new_int;
            } else {
                rotate_int -= new_int - cur_int;
            }
            animate_slider();
        });

        return {
            next: function () {
                rotate_int -= 1;
                animate_slider();
                return rotate_int;
            },
            prev: function () {
                rotate_int += 1;
                animate_slider();
                return rotate_int;
            }
	};

}
})(jQuery);

